# 🚀 NEW LOOK FASHION - Quick Reference Card

## 📋 Quick Commands

```bash
# Start development
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Push database changes
npx drizzle-kit push

# Check TypeScript errors
npm run typecheck
```

## 🔐 Admin Login Credentials

| Field | Value |
|-------|-------|
| URL | `/admin` |
| Phone | `6394038329` |
| Password | `6394038329` |
| OTP | Valid for 10 seconds only |

## 📁 Important Files

| File | Purpose |
|------|---------|
| `src/app/page.tsx` | Home page |
| `src/app/admin/page.tsx` | Admin panel |
| `src/db/schema.ts` | Database tables |
| `src/app/api/products/route.ts` | Products API |
| `src/lib/auth.ts` | Authentication |
| `.env` | Environment variables |

## 🌐 API Endpoints

| Method | Endpoint | Purpose | Auth |
|--------|----------|---------|------|
| GET | `/api/products` | List all products | No |
| POST | `/api/products` | Add product | Yes |
| GET | `/api/products/[id]` | Get single product | No |
| PUT | `/api/products/[id]` | Update product | Yes |
| DELETE | `/api/products/[id]` | Delete product | Yes |
| POST | `/api/auth/login` | Admin login | No |
| POST | `/api/upload` | Upload image | Yes |

## 🎨 Color Theme

```css
Sky Blue:    #0ea5e9 (Primary)
Sky Light:   #7dd3fc 
Sky Dark:    #0369a1
Black:       #000000 (Background)
White:       #ffffff (Text)
Gray:        #1f2937 (Cards)
```

## 📱 Contact Info

- **Phone**: 6384038329
- **WhatsApp**: 6394038329
- **Shop**: NEW LOOK FASHION
- **Website**: newlookfz

## 🏬 Branch Locations

1. **Main**: Bichhiya, Gorakhpur (Near KMG Vatika School)
2. **Branch 2**: Neena Thapa, Gorakhpur
3. **Branch 3**: Jhumila Bazar, Badhahalganj

## ✨ Features Checklist

- [x] FZ Logo with animation
- [x] Running marquee text
- [x] Product display with images
- [x] Price with discount
- [x] Sizes: S, M, L, XL, XXL
- [x] In Stock / Out of Stock
- [x] Article codes
- [x] Image zoom
- [x] WhatsApp order
- [x] UPI payment mention
- [x] 3 branches display
- [x] Admin login with OTP
- [x] Product CRUD operations
- [x] Image upload
- [x] Price filter (low to high)
- [x] Category filter
- [x] Stock filter
- [x] Download app feature
- [x] Wholesale available notice
- [x] No COD notice
- [x] Mobile responsive

## 🔧 Troubleshooting

| Problem | Solution |
|---------|----------|
| Database error | Check `.env` DATABASE_URL |
| Login fails | Use phone: 6394038329, password: 6394038329 |
| OTP expired | It's only 10 seconds, be quick! |
| Image upload fails | Check admin is logged in |
| Products not showing | Run `npx drizzle-kit push` |
| Build fails | Run `npm run typecheck` to find errors |

## 📦 Tech Stack

```
Frontend:  Next.js 16 + React 19 + Tailwind CSS 4
Backend:   Next.js API Routes
Database:  PostgreSQL + Drizzle ORM
Auth:      bcryptjs + Custom tokens
Language:  TypeScript
```

---
*NEW LOOK FASHION (newlookfz) - Premium Menswear*
