import { NextRequest, NextResponse } from "next/server";
import { verifyAdmin, generateToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const { phone, password } = await req.json();
    if (!phone || !password) {
      return NextResponse.json({ error: "Phone and password required" }, { status: 400 });
    }
    const valid = await verifyAdmin(phone, password);
    if (!valid) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }
    const token = generateToken(phone);
    return NextResponse.json({ token, message: "Login successful" });
  } catch {
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
