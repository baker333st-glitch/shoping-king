import { db } from "@/db";
import { admins } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

const ADMIN_PHONE = "6394038329";

export async function ensureAdminExists() {
  const existing = await db.select().from(admins).where(eq(admins.phone, ADMIN_PHONE));
  if (existing.length === 0) {
    const hash = await bcrypt.hash("6394038329", 10);
    await db.insert(admins).values({
      phone: ADMIN_PHONE,
      passwordHash: hash,
    });
  }
}

export async function verifyAdmin(phone: string, password: string): Promise<boolean> {
  await ensureAdminExists();
  const admin = await db.select().from(admins).where(eq(admins.phone, phone));
  if (admin.length === 0) return false;
  return bcrypt.compare(password, admin[0].passwordHash);
}

// Simple token: base64 of phone + timestamp
export function generateToken(phone: string): string {
  const payload = JSON.stringify({ phone, ts: Date.now() });
  return Buffer.from(payload).toString("base64");
}

export function verifyToken(token: string): boolean {
  try {
    const payload = JSON.parse(Buffer.from(token, "base64").toString());
    // Token valid for 24 hours
    return payload.phone === ADMIN_PHONE && Date.now() - payload.ts < 86400000;
  } catch {
    return false;
  }
}
