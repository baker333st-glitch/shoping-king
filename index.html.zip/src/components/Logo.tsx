"use client";

export default function Logo({ size = "text-4xl" }: { size?: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <div className="bg-gradient-to-br from-skyblue to-skyblue-dark rounded-lg p-2 animate-pulse-glow">
          <span className={`${size} font-black text-white tracking-tighter`}>FZ</span>
        </div>
      </div>
      <div className="flex flex-col">
        <span className="text-lg font-bold text-skyblue leading-tight">NEW LOOK</span>
        <span className="text-xs font-semibold text-skyblue-light tracking-widest">FASHION</span>
      </div>
    </div>
  );
}
